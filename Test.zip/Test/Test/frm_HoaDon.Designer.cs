﻿namespace Test
{
    partial class frm_HoaDon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pn_DanhSach = new System.Windows.Forms.Panel();
            this.pn_HoaDonDatMon = new System.Windows.Forms.Panel();
            this.nud_SoLuong = new System.Windows.Forms.NumericUpDown();
            this.btn_ThanhToan = new System.Windows.Forms.Button();
            this.txt_TongTien = new System.Windows.Forms.TextBox();
            this.cb_Mon = new System.Windows.Forms.ComboBox();
            this.lb_TongTien = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_ThemMon = new System.Windows.Forms.Button();
            this.dt_gridMon = new System.Windows.Forms.DataGridView();
            this.btn_InHoaDon = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_Ban12 = new System.Windows.Forms.Button();
            this.btn_Ban1 = new System.Windows.Forms.Button();
            this.btn_Ban2 = new System.Windows.Forms.Button();
            this.btn_Ban3 = new System.Windows.Forms.Button();
            this.btn_Ban4 = new System.Windows.Forms.Button();
            this.btn_Ban6 = new System.Windows.Forms.Button();
            this.btn_Ban5 = new System.Windows.Forms.Button();
            this.btn_Ban11 = new System.Windows.Forms.Button();
            this.btn_Ban8 = new System.Windows.Forms.Button();
            this.btn_Ban9 = new System.Windows.Forms.Button();
            this.btn_Ban10 = new System.Windows.Forms.Button();
            this.btn_Ban7 = new System.Windows.Forms.Button();
            this.pn_DanhSach.SuspendLayout();
            this.pn_HoaDonDatMon.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_SoLuong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_gridMon)).BeginInit();
            this.SuspendLayout();
            // 
            // pn_DanhSach
            // 
            this.pn_DanhSach.Controls.Add(this.pn_HoaDonDatMon);
            this.pn_DanhSach.Controls.Add(this.btn_InHoaDon);
            this.pn_DanhSach.Controls.Add(this.label2);
            this.pn_DanhSach.Controls.Add(this.btn_Ban12);
            this.pn_DanhSach.Controls.Add(this.btn_Ban1);
            this.pn_DanhSach.Controls.Add(this.btn_Ban2);
            this.pn_DanhSach.Controls.Add(this.btn_Ban3);
            this.pn_DanhSach.Controls.Add(this.btn_Ban4);
            this.pn_DanhSach.Controls.Add(this.btn_Ban6);
            this.pn_DanhSach.Controls.Add(this.btn_Ban5);
            this.pn_DanhSach.Controls.Add(this.btn_Ban11);
            this.pn_DanhSach.Controls.Add(this.btn_Ban8);
            this.pn_DanhSach.Controls.Add(this.btn_Ban9);
            this.pn_DanhSach.Controls.Add(this.btn_Ban10);
            this.pn_DanhSach.Controls.Add(this.btn_Ban7);
            this.pn_DanhSach.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pn_DanhSach.Location = new System.Drawing.Point(0, 0);
            this.pn_DanhSach.Name = "pn_DanhSach";
            this.pn_DanhSach.Size = new System.Drawing.Size(939, 624);
            this.pn_DanhSach.TabIndex = 26;
            // 
            // pn_HoaDonDatMon
            // 
            this.pn_HoaDonDatMon.Controls.Add(this.nud_SoLuong);
            this.pn_HoaDonDatMon.Controls.Add(this.btn_ThanhToan);
            this.pn_HoaDonDatMon.Controls.Add(this.txt_TongTien);
            this.pn_HoaDonDatMon.Controls.Add(this.cb_Mon);
            this.pn_HoaDonDatMon.Controls.Add(this.lb_TongTien);
            this.pn_HoaDonDatMon.Controls.Add(this.label3);
            this.pn_HoaDonDatMon.Controls.Add(this.btn_ThemMon);
            this.pn_HoaDonDatMon.Controls.Add(this.dt_gridMon);
            this.pn_HoaDonDatMon.Dock = System.Windows.Forms.DockStyle.Right;
            this.pn_HoaDonDatMon.Location = new System.Drawing.Point(448, 0);
            this.pn_HoaDonDatMon.Name = "pn_HoaDonDatMon";
            this.pn_HoaDonDatMon.Size = new System.Drawing.Size(491, 624);
            this.pn_HoaDonDatMon.TabIndex = 29;
            // 
            // nud_SoLuong
            // 
            this.nud_SoLuong.Location = new System.Drawing.Point(422, 128);
            this.nud_SoLuong.Name = "nud_SoLuong";
            this.nud_SoLuong.Size = new System.Drawing.Size(43, 22);
            this.nud_SoLuong.TabIndex = 29;
            // 
            // btn_ThanhToan
            // 
            this.btn_ThanhToan.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btn_ThanhToan.Location = new System.Drawing.Point(369, 468);
            this.btn_ThanhToan.Name = "btn_ThanhToan";
            this.btn_ThanhToan.Size = new System.Drawing.Size(96, 100);
            this.btn_ThanhToan.TabIndex = 26;
            this.btn_ThanhToan.Text = "Thanh Toán ";
            this.btn_ThanhToan.UseVisualStyleBackColor = false;
            this.btn_ThanhToan.Click += new System.EventHandler(this.btn_ThanhToan_Click);
            // 
            // txt_TongTien
            // 
            this.txt_TongTien.Location = new System.Drawing.Point(51, 516);
            this.txt_TongTien.Multiline = true;
            this.txt_TongTien.Name = "txt_TongTien";
            this.txt_TongTien.Size = new System.Drawing.Size(223, 32);
            this.txt_TongTien.TabIndex = 28;
            // 
            // cb_Mon
            // 
            this.cb_Mon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb_Mon.FormattingEnabled = true;
            this.cb_Mon.ItemHeight = 16;
            this.cb_Mon.Location = new System.Drawing.Point(51, 126);
            this.cb_Mon.Name = "cb_Mon";
            this.cb_Mon.Size = new System.Drawing.Size(250, 24);
            this.cb_Mon.TabIndex = 21;
            // 
            // lb_TongTien
            // 
            this.lb_TongTien.AutoSize = true;
            this.lb_TongTien.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_TongTien.Location = new System.Drawing.Point(47, 477);
            this.lb_TongTien.Name = "lb_TongTien";
            this.lb_TongTien.Size = new System.Drawing.Size(109, 24);
            this.lb_TongTien.TabIndex = 27;
            this.lb_TongTien.Text = "Tổng Tiền :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(131, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(226, 31);
            this.label3.TabIndex = 19;
            this.label3.Text = "Hóa Đơn Đặt Món";
            // 
            // btn_ThemMon
            // 
            this.btn_ThemMon.Location = new System.Drawing.Point(323, 117);
            this.btn_ThemMon.Name = "btn_ThemMon";
            this.btn_ThemMon.Size = new System.Drawing.Size(75, 67);
            this.btn_ThemMon.TabIndex = 22;
            this.btn_ThemMon.Text = "Thêm Món";
            this.btn_ThemMon.UseVisualStyleBackColor = true;
            this.btn_ThemMon.Click += new System.EventHandler(this.btn_ThemMon_Click_1);
            // 
            // dt_gridMon
            // 
            this.dt_gridMon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dt_gridMon.GridColor = System.Drawing.Color.White;
            this.dt_gridMon.Location = new System.Drawing.Point(31, 196);
            this.dt_gridMon.Name = "dt_gridMon";
            this.dt_gridMon.RowHeadersWidth = 51;
            this.dt_gridMon.RowTemplate.Height = 24;
            this.dt_gridMon.Size = new System.Drawing.Size(434, 246);
            this.dt_gridMon.TabIndex = 24;
            // 
            // btn_InHoaDon
            // 
            this.btn_InHoaDon.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btn_InHoaDon.Location = new System.Drawing.Point(240, 462);
            this.btn_InHoaDon.Name = "btn_InHoaDon";
            this.btn_InHoaDon.Size = new System.Drawing.Size(126, 118);
            this.btn_InHoaDon.TabIndex = 25;
            this.btn_InHoaDon.Text = "In  Hóa Đơn ";
            this.btn_InHoaDon.UseVisualStyleBackColor = false;
            this.btn_InHoaDon.Click += new System.EventHandler(this.btn_InHoaDon_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(83, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(233, 37);
            this.label2.TabIndex = 18;
            this.label2.Text = "Danh Sách Bàn ";
            // 
            // btn_Ban12
            // 
            this.btn_Ban12.BackColor = System.Drawing.Color.Coral;
            this.btn_Ban12.FlatAppearance.BorderColor = System.Drawing.Color.Coral;
            this.btn_Ban12.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Cyan;
            this.btn_Ban12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSalmon;
            this.btn_Ban12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Ban12.Location = new System.Drawing.Point(286, 366);
            this.btn_Ban12.Name = "btn_Ban12";
            this.btn_Ban12.Size = new System.Drawing.Size(80, 78);
            this.btn_Ban12.TabIndex = 13;
            this.btn_Ban12.Text = "bàn 12";
            this.btn_Ban12.UseVisualStyleBackColor = false;
            // 
            // btn_Ban1
            // 
            this.btn_Ban1.BackColor = System.Drawing.Color.Coral;
            this.btn_Ban1.FlatAppearance.BorderColor = System.Drawing.Color.Coral;
            this.btn_Ban1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Cyan;
            this.btn_Ban1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSalmon;
            this.btn_Ban1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Ban1.Location = new System.Drawing.Point(31, 114);
            this.btn_Ban1.Name = "btn_Ban1";
            this.btn_Ban1.Size = new System.Drawing.Size(80, 78);
            this.btn_Ban1.TabIndex = 2;
            this.btn_Ban1.Text = "bàn 1";
            this.btn_Ban1.UseVisualStyleBackColor = false;
            // 
            // btn_Ban2
            // 
            this.btn_Ban2.BackColor = System.Drawing.Color.Coral;
            this.btn_Ban2.FlatAppearance.BorderColor = System.Drawing.Color.Coral;
            this.btn_Ban2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Cyan;
            this.btn_Ban2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSalmon;
            this.btn_Ban2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Ban2.Location = new System.Drawing.Point(162, 114);
            this.btn_Ban2.Name = "btn_Ban2";
            this.btn_Ban2.Size = new System.Drawing.Size(80, 78);
            this.btn_Ban2.TabIndex = 3;
            this.btn_Ban2.Text = "bàn 2";
            this.btn_Ban2.UseVisualStyleBackColor = false;
            // 
            // btn_Ban3
            // 
            this.btn_Ban3.BackColor = System.Drawing.Color.Coral;
            this.btn_Ban3.FlatAppearance.BorderColor = System.Drawing.Color.Coral;
            this.btn_Ban3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Cyan;
            this.btn_Ban3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSalmon;
            this.btn_Ban3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Ban3.Location = new System.Drawing.Point(286, 115);
            this.btn_Ban3.Name = "btn_Ban3";
            this.btn_Ban3.Size = new System.Drawing.Size(80, 78);
            this.btn_Ban3.TabIndex = 4;
            this.btn_Ban3.Text = "bàn 3";
            this.btn_Ban3.UseVisualStyleBackColor = false;
            // 
            // btn_Ban4
            // 
            this.btn_Ban4.BackColor = System.Drawing.Color.Coral;
            this.btn_Ban4.FlatAppearance.BorderColor = System.Drawing.Color.Coral;
            this.btn_Ban4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Cyan;
            this.btn_Ban4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSalmon;
            this.btn_Ban4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Ban4.Location = new System.Drawing.Point(31, 198);
            this.btn_Ban4.Name = "btn_Ban4";
            this.btn_Ban4.Size = new System.Drawing.Size(80, 78);
            this.btn_Ban4.TabIndex = 5;
            this.btn_Ban4.Text = "bàn 4";
            this.btn_Ban4.UseVisualStyleBackColor = false;
            // 
            // btn_Ban6
            // 
            this.btn_Ban6.BackColor = System.Drawing.Color.Coral;
            this.btn_Ban6.FlatAppearance.BorderColor = System.Drawing.Color.Coral;
            this.btn_Ban6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Cyan;
            this.btn_Ban6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSalmon;
            this.btn_Ban6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Ban6.Location = new System.Drawing.Point(286, 199);
            this.btn_Ban6.Name = "btn_Ban6";
            this.btn_Ban6.Size = new System.Drawing.Size(80, 78);
            this.btn_Ban6.TabIndex = 7;
            this.btn_Ban6.Text = "bàn 6";
            this.btn_Ban6.UseVisualStyleBackColor = false;
            // 
            // btn_Ban5
            // 
            this.btn_Ban5.BackColor = System.Drawing.Color.Coral;
            this.btn_Ban5.FlatAppearance.BorderColor = System.Drawing.Color.Coral;
            this.btn_Ban5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Cyan;
            this.btn_Ban5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSalmon;
            this.btn_Ban5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Ban5.Location = new System.Drawing.Point(162, 198);
            this.btn_Ban5.Name = "btn_Ban5";
            this.btn_Ban5.Size = new System.Drawing.Size(80, 78);
            this.btn_Ban5.TabIndex = 6;
            this.btn_Ban5.Text = "bàn 5";
            this.btn_Ban5.UseVisualStyleBackColor = false;
            // 
            // btn_Ban11
            // 
            this.btn_Ban11.BackColor = System.Drawing.Color.Coral;
            this.btn_Ban11.FlatAppearance.BorderColor = System.Drawing.Color.Coral;
            this.btn_Ban11.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Cyan;
            this.btn_Ban11.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSalmon;
            this.btn_Ban11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Ban11.Location = new System.Drawing.Point(162, 366);
            this.btn_Ban11.Name = "btn_Ban11";
            this.btn_Ban11.Size = new System.Drawing.Size(80, 78);
            this.btn_Ban11.TabIndex = 12;
            this.btn_Ban11.Text = "bàn 11";
            this.btn_Ban11.UseVisualStyleBackColor = false;
            // 
            // btn_Ban8
            // 
            this.btn_Ban8.BackColor = System.Drawing.Color.Coral;
            this.btn_Ban8.FlatAppearance.BorderColor = System.Drawing.Color.Coral;
            this.btn_Ban8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Cyan;
            this.btn_Ban8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSalmon;
            this.btn_Ban8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Ban8.Location = new System.Drawing.Point(162, 282);
            this.btn_Ban8.Name = "btn_Ban8";
            this.btn_Ban8.Size = new System.Drawing.Size(80, 78);
            this.btn_Ban8.TabIndex = 9;
            this.btn_Ban8.Text = "bàn 8";
            this.btn_Ban8.UseVisualStyleBackColor = false;
            // 
            // btn_Ban9
            // 
            this.btn_Ban9.BackColor = System.Drawing.Color.Coral;
            this.btn_Ban9.FlatAppearance.BorderColor = System.Drawing.Color.Coral;
            this.btn_Ban9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Cyan;
            this.btn_Ban9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSalmon;
            this.btn_Ban9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Ban9.Location = new System.Drawing.Point(286, 282);
            this.btn_Ban9.Name = "btn_Ban9";
            this.btn_Ban9.Size = new System.Drawing.Size(80, 78);
            this.btn_Ban9.TabIndex = 10;
            this.btn_Ban9.Text = "bàn 9";
            this.btn_Ban9.UseVisualStyleBackColor = false;
            // 
            // btn_Ban10
            // 
            this.btn_Ban10.BackColor = System.Drawing.Color.Coral;
            this.btn_Ban10.FlatAppearance.BorderColor = System.Drawing.Color.Coral;
            this.btn_Ban10.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Cyan;
            this.btn_Ban10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSalmon;
            this.btn_Ban10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Ban10.Location = new System.Drawing.Point(31, 366);
            this.btn_Ban10.Name = "btn_Ban10";
            this.btn_Ban10.Size = new System.Drawing.Size(80, 78);
            this.btn_Ban10.TabIndex = 11;
            this.btn_Ban10.Text = "bàn 10";
            this.btn_Ban10.UseVisualStyleBackColor = false;
            // 
            // btn_Ban7
            // 
            this.btn_Ban7.BackColor = System.Drawing.Color.Coral;
            this.btn_Ban7.FlatAppearance.BorderColor = System.Drawing.Color.Coral;
            this.btn_Ban7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Cyan;
            this.btn_Ban7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSalmon;
            this.btn_Ban7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Ban7.Location = new System.Drawing.Point(31, 282);
            this.btn_Ban7.Name = "btn_Ban7";
            this.btn_Ban7.Size = new System.Drawing.Size(80, 78);
            this.btn_Ban7.TabIndex = 8;
            this.btn_Ban7.Text = "bàn 7";
            this.btn_Ban7.UseVisualStyleBackColor = false;
            // 
            // frm_HoaDon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(939, 624);
            this.Controls.Add(this.pn_DanhSach);
            this.Name = "frm_HoaDon";
            this.Text = "frm_HoaDon";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frm_HoaDon_Load);
            this.pn_DanhSach.ResumeLayout(false);
            this.pn_DanhSach.PerformLayout();
            this.pn_HoaDonDatMon.ResumeLayout(false);
            this.pn_HoaDonDatMon.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_SoLuong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_gridMon)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pn_DanhSach;
        private System.Windows.Forms.Panel pn_HoaDonDatMon;
        private System.Windows.Forms.NumericUpDown nud_SoLuong;
        private System.Windows.Forms.Button btn_ThanhToan;
        private System.Windows.Forms.TextBox txt_TongTien;
        private System.Windows.Forms.ComboBox cb_Mon;
        private System.Windows.Forms.Label lb_TongTien;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_ThemMon;
        private System.Windows.Forms.DataGridView dt_gridMon;
        private System.Windows.Forms.Button btn_InHoaDon;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_Ban12;
        private System.Windows.Forms.Button btn_Ban1;
        private System.Windows.Forms.Button btn_Ban2;
        private System.Windows.Forms.Button btn_Ban3;
        private System.Windows.Forms.Button btn_Ban4;
        private System.Windows.Forms.Button btn_Ban6;
        private System.Windows.Forms.Button btn_Ban5;
        private System.Windows.Forms.Button btn_Ban11;
        private System.Windows.Forms.Button btn_Ban8;
        private System.Windows.Forms.Button btn_Ban9;
        private System.Windows.Forms.Button btn_Ban10;
        private System.Windows.Forms.Button btn_Ban7;
    }
}